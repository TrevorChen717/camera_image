#!/usr/bin/env python3
import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError

class ImageProcessor:
    def __init__(self):
        # Initialize ROS node
        rospy.init_node('image_processor', anonymous=True)

        # Initialize CvBridge for converting ROS Image messages to OpenCV format
        self.bridge = CvBridge()

        # Subscribe to the /camera/image_raw topic
        rospy.Subscriber('/camera_image/image_raw', Image, self.image_callback)

        # Publisher for the resized image
        self.image_pub = rospy.Publisher('/camera_image/image_resized', Image, queue_size=10)

    def image_callback(self, msg):
        try:
            # Convert ROS Image message to OpenCV image
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except CvBridgeError as e:
            rospy.logerr(f"Failed to convert image: {e}")
            return

        # Process the image to make it square and resize to 512x512
        processed_image = self.make_square_and_resize(cv_image)

        try:
            # Convert OpenCV image back to ROS Image message
            ros_image = self.bridge.cv2_to_imgmsg(processed_image, encoding='bgr8')
            # Publish the resized image
            self.image_pub.publish(ros_image)
        except CvBridgeError as e:
            rospy.logerr(f"Failed to convert and publish image: {e}")

    def make_square_and_resize(self, image):
        """Pad the image with black pixels to make it square and resize to 512x512."""
        height, width = image.shape[:2]
        size = max(height, width)

        # Create a black square image with the target size
        square_image = np.zeros((size, size, 3), dtype=np.uint8)

        # Calculate the offset to center the original image
        y_offset = (size - height) // 2
        x_offset = (size - width) // 2

        # Place the original image in the center of the square image
        square_image[y_offset:y_offset + height, x_offset:x_offset + width] = image

        # Resize the image to 512x512
        resized_image = cv2.resize(square_image, (512, 512), interpolation=cv2.INTER_LINEAR)
        return resized_image

    def run(self):
        # Keep the node running
        rospy.spin()

if __name__ == '__main__':
    try:
        processor = ImageProcessor()
        processor.run()
    except rospy.ROSInterruptException:
        pass

