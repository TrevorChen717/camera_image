#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import Image
from std_msgs.msg import Header, Time
from cv_bridge import CvBridge
import cv2

def publish_camera():
    # Initialize the ROS node
    rospy.init_node('camera_publisher', anonymous=False)

    # Retrieve parameters from the Parameter Server
    width = rospy.get_param('camera_info/width', 1280)
    height = rospy.get_param('camera_info/height', 720)
    fps = rospy.get_param('camera_info/fps', 30.0)

    rospy.loginfo(f"Starting camera with resolution: {width}x{height} @ {fps} FPS")

    # Set up publishers
    image_pub = rospy.Publisher('/camera_image/image_raw', Image, queue_size=10)
    timestamp_pub = rospy.Publisher('/camera_image/timestamp', Time, queue_size=10)

    bridge = CvBridge()
    cap = cv2.VideoCapture('/dev/video0')
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    cap.set(cv2.CAP_PROP_FPS, fps)

    if not cap.isOpened():
        rospy.logerr("Failed to open camera device.")
        return

    rate = rospy.Rate(fps)

    while not rospy.is_shutdown():
        ret, frame = cap.read()
        if not ret:
            rospy.logerr("Failed to capture frame.")
            break

        # Publish the current timestamp
        current_time = rospy.Time.now()
        timestamp_pub.publish(current_time)

        # Convert OpenCV image to ROS Image message and publish
        image_message = bridge.cv2_to_imgmsg(frame, encoding="bgr8")
        image_message.header = Header(stamp=current_time, frame_id='camera_frame')
        image_pub.publish(image_message)

        rospy.loginfo(f"Published frame at {current_time}")
        rate.sleep()

    cap.release()
    rospy.loginfo("Shutting down camera publisher.")

if __name__ == '__main__':
    try:
        publish_camera()
    except rospy.ROSInterruptException:
        pass

